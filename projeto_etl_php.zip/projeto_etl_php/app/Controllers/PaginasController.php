<?php

class PaginasController extends Controller{

    private $db;

    function __construct() {
        $this->db = new Database;
    }

    public function index(){
        

        $listaUnidades = $this->listarUnidades();
        $listaProdutos = $this->listarProdutos();

        $dados = (object) ['titulo'=>'Filtrar Inadimplências', 'descricao' => 'Curso de PHP7', 'unidades' => $listaUnidades, 'produtos' => $listaProdutos];

        $this->view('paginas/home', $dados );
    }

    public function sobre(){
        $dados = ['titulo'=>'Sobre', 'descricao' => 'Descrição qualquer'];
        $this->view('paginas/sobre', $dados );
    }

    public function filtro(){
        // var_dump($_REQUEST)."<br>";
        // echo "<pre>";
        // print_r($_POST);
        // echo "</pre>";
        $dataInicio = $_POST["inicial"];
        $dataFim = $_POST["final"];

        //echo $dataInicio.'<br>';
        $dataInicioArray= explode("-", $dataInicio);
        $dataInicioParam = $dataInicioArray[0].$dataInicioArray[1].$dataInicioArray[2];
        //echo $dataInicioParam;

        $dataFimArray= explode("-", $dataFim);
        $dataFimParam = $dataFimArray[0].$dataFimArray[1].$dataFimArray[2];

        $query = $this->retornaQuery($dataInicioParam, $dataFimParam, 0, 0);

        $inadimplencias = $this->retornaListaInadimplencia($query);

        //var_dump($inadimplencias);

        $dados = (object)['titulo'=>'Tabela', 'descricao' => 'Testando carregamento tabela dinamica', "inadimplencias" => $inadimplencias] ;
        $this->view('paginas/filtro', $dados);
    }

    private function listarUnidades(){
        $this->db->query("SELECT * FROM DIM_UNIDADES");
        $this->db->executa();
        return $this->db->resultados();
    }

    private function listarProdutos(){
        $this->db->query("SELECT * FROM DIM_PRODUTOS");
        $this->db->executa();
        return $this->db->resultados();
    }

    private function retornaQuery($data_inicial, $data_final, $id_produto, $id_unidade){
        $int_data_inicial = intval($data_inicial);
        $int_data_final = intval($data_final);
        $query = "
                SELECT ROUND(SUM(VALOR_BASE), 2) AS TOTAL 
                ,I.ID_POSICAO 
                ,T.Data_Arquivo AS DATA ,
                I.CO_UNIDADE AS ID_UNIDADE,
                U.no_unidade AS NOME_UNIDADE, 
                I.NU_PRODUTO AS NOME_PRODUTO,
                P.no_produto AS ID_PRODUTO 
                FROM FATO_INADIMPLENCIA AS I 
                LEFT JOIN DIM_UNIDADES AS U 
                ON I.CO_UNIDADE = U.co_unidade 
                LEFT JOIN DIM_PRODUTOS AS P 
                ON I.NU_PRODUTO = P.nu_produto 
                LEFT JOIN DIM_POSICAO AS T 
                ON I.ID_POSICAO = T.Id_Posicao 
                ";

        //echo $query;
        $where = " WHERE I.ID_POSICAO >= ".$int_data_inicial." OR I.ID_POSICAO <=". $int_data_final." " ;
        $query = $query.$where;

        $and ="";
        if($id_produto != 0){
            $and = " AND I.NU_PRODUTO = $id_produto ";
        }

        if($id_unidade != 0){
            $and = " AND I.CO_UNIDADE = $id_unidade ";
        }
        $query = $query.$and;

        $group_by = " GROUP BY I.ID_POSICAO ,T.Data_Arquivo, I.CO_UNIDADE, U.no_unidade, I.NU_PRODUTO, P.no_produto ";
        $query = $query.$group_by;

        //echo $query;

        return $query;
    }

    private function retornaListaInadimplencia($query){
        $this->db->query($query);
        $this->db->executa();
        return $this->db->resultados();
    }

    // public function ajaxfile(){
    //     echo $_SERVER['HTTP_REFERER']."<br>";

    //     $db = new Database();
    //     echo "Entrou na controller"."<br>";
    //     var_dump($_POST['draw'])."<br>";

    //     ## Read value
    //     $draw = $_POST['draw'];
    //     $row = $_POST['start'];
    //     $rowperpage = $_POST['length']; // Rows display per page
    //     $columnIndex = $_POST['order'][0]['column']; // Column index
    //     $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
    //     $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
    //     $searchValue = $_POST['search']['value']; // Search value

    //     $searchArray = array();

    //     ## Search 
        // $searchQuery = " ";
        // if ($searchValue != '') {
        //     $searchQuery = " AND (DATA_ARQUIVO LIKE :DATA_ARQUIVO or 
        //                  VALOR_BASE LIKE :VALOR_BASE OR 
        //                  CO_UNIDADE LIKE :CO_UNIDADE OR
        //                  NU_PRODUTO' LIKE :NU_PRODUTO' OR 
        //                  NU_CONTRATO LIKE :NU_CONTRATO 
        //                 ) ";
        //     $searchArray = array(
        //         'DATA_ARQUIVO' => "%$searchValue%",
        //         'VALOR_BASE' => "%$searchValue%",
        //         'CO_UNIDADE' => "%$searchValue%",
        //         'NU_PRODUTO' => "%$searchValue%",
        //         'NU_CONTRATO' => "%$searchValue%"
        //     );
        // }

    //     ## Total number of records without filtering
    //     $queryString = "SELECT COUNT(*) AS allcount FROM  ";
    //     $db->query($queryString);
    //     $db->executa();

    //     $records = $db->resultado();//equivale ao fetch(PDO::FETCH_OBJ);
    //     //$records = $this->stmt->fetch(PDO::FETCH_OBJ);
    //     $totalRecords = $records['allcount'];

    //     ## Total number of records with filtering
    //     $db->query("SELECT COUNT(*) AS allcount FROM TAB_CONTRATOS WHERE 1 " . $searchQuery);
    //     //$stmt = $this->dbh->prepare("SELECT COUNT(*) AS allcount FROM TAB_CONTRATOS WHERE 1 " . $searchQuery);
    //     $db->executa();
    //     //$stmt->execute($searchArray);
    //     $records = $db->resultado();;
    //     //$records = $stmt->fetch(PDO::FETCH_OBJ);
    //     $totalRecordwithFilter = $records['allcount'];

    //     ## Fetch records
    //     $db->query("SELECT * FROM TAB_CONTRATOS WHERE 1 " . $searchQuery . " ORDER BY " . $columnName . " " . $columnSortOrder . " LIMIT :limit,:offset");
    //     //$stmt = $this->dbh->prepare("SELECT * FROM TAB_CONTRATOS WHERE 1 " . $searchQuery . " ORDER BY " . $columnName . " " . $columnSortOrder . " LIMIT :limit,:offset");

    //     // Bind values
    //     foreach ($searchArray as $key => $search) {
    //         $db->bind(':' . $key, $search, PDO::PARAM_STR);
    //         //$stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
    //     }

    //     $db->bind(':limit', (int)$row, PDO::PARAM_INT);
    //     $db->bind(':offset', (int)$rowperpage, PDO::PARAM_INT);
    //     $db->executa();
    //     $empRecords = $db->resultados();
        

    //     // $stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
    //     // $stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
    //     // $stmt->execute();
    //     // $empRecords = $stmt->fetchAll(PDO::FETCH_OBJ);

    //     $data = (object)array();

    //     foreach ($empRecords as $row) {
    //         // $data[] = array(
    //         //     "DATA_ARQUIVO" => $row['DATA_ARQUIVO'],
    //         //     "VALOR_BASE" => $row['VALOR_BASE'],
    //         //     "CO_UNIDADE" => $row['CO_UNIDADE'],
    //         //     "NU_PRODUTO" => $row['NU_PRODUTO'],
    //         //     "NU_CONTRATO" => $row['NU_CONTRATO']
    //         // );
    //         $data->DATA_ARQUIVO = $row['DATA_ARQUIVO'];
    //         $data->DATA_ARQUIVO = $row['DATA_ARQUIVO'];
    //         $data->VALOR_BASE = $row['VALOR_BASE'];
    //         $data->CO_UNIDADE = $row['CO_UNIDADE'];
    //         $data->NU_PRODUTO = $row['NU_PRODUTO'];
    //         $data->NU_CONTRATO = $row['NU_CONTRATO'];
    //     }

    //     ## Response
    //     // $response = array(
    //     //     "draw" => intval($draw),
    //     //     "iTotalRecords" => $totalRecords,
    //     //     "iTotalDisplayRecords" => $totalRecordwithFilter,
    //     //     "aaData" => $data
    //     // );

    //     // $response = json_decode("{}");
    //     // $response->intval($draw);
    //     // $response->draw->intval($draw);
    //     // $response->iTotalRecords = $totalRecords;
    //     // $response->iTotalDisplayRecords  = $totalRecordwithFilter;
    //     // $response->aaData = $data;

    //     $response = (object)[];
    //     $response->intval($draw);
    //     $response->draw->intval($draw);
    //     $response->iTotalRecords = $totalRecords;
    //     $response->iTotalDisplayRecords  = $totalRecordwithFilter;
    //     $response->aaData = $data;


    //     // echo $response;
    //     // var_dump($response);

    //     //echo json_encode($response);
    //     return $response;

    // }

}
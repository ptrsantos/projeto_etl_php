<?php

class Database
{

    private $host = "DESKTOP-7BD8DLA";
    private $banco = "PSI_ETL_DW";
    private $usuario = "";
    private $senha = "";
    private $dbh;
    private $stmt;

    public function __construct()
    {
        //fonte de dados ou DSN que contém as informações necessárias para conectar ao banco de dados.
        $dsn = "sqlsrv:server=$this->host; Database=$this->banco";
        try {
            $this->dbh = new PDO($dsn, $this->usuario, $this->senha);

            #armazena em cache a conexão para ser reutilizada, evita a sobrecarga de uma nova conexão, resultando em um aplicativo mais rápido.
            $this->dbh->setAttribute(PDO::ATTR_PERSISTENT, true);
            #lança uma PDOException se ocorrer um erro.
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);;
            //echo "Conectado com sucesso!";
        } catch (Exception $e) {
            die(print_r($e->getMessage()));
        }
    }

    public function query($sql)
    {
        $this->stmt = $this->dbh->prepare($sql);
    }

    public function bind($parametro, $valor, $tipo = null)
    {
        if (is_null($tipo)) :
            switch (true):
                case is_int($valor):
                    $tipo = PDO::PARAM_INT;
                    break;
                case is_bool($valor):
                    $tipo = PDO::PARAM_BOOL;
                    break;
                case is_null($valor):
                    $tipo = PDO::PARAM_NULL;
                    break;
                default:
                    $tipo = PDO::PARAM_STR;
            endswitch;
        endif;

        $this->stmt->bindValue($parametro, $valor, $tipo);
    }

    public function executa()
    {
        return $this->stmt->execute();
    }

    public function resultado()
    {
        $this->executa();
        return $this->stmt->fetch(PDO::FETCH_OBJ);
    }

    public function resultados()
    {
        $this->executa();
        return $this->stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function totalResultados()
    {
        return $this->stmt->rowCount();
    }

    public function ultimoIdInserido()
    {
        return $this->stmt->lastInsertId();
    }

}

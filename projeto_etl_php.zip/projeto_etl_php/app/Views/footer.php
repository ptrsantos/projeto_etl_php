<footer class="bg-primary p-1 text-light fixar-rodape">
    <div class="container-fluid">
        <small>
            Projeto de PHP 7 ETL. Versão: <?= APP_VERSAO ?>
            <div class="border-top">
                &COPY; <?= date('Y') ?> - Paulo de Tarso Rodrigues dos Santos - matricula: C058946-4
            </div>
        </small>
    </div>
</footer>
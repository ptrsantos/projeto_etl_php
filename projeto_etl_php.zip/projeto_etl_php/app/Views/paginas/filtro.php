<table id='filtro' class='display dataTable'>

    <thead>
        <tr>
            <th>DATA</th>
            <th>VALOR</th>
            <th>UNIDADE</th>
            <th>PRODUTO</th>

        </tr>
    </thead>
    <tbody>
        <?php $cont = 0;
            foreach ($dados->inadimplencias as $item) { ?>
            <tr>
                <td><?php echo $item->DATA; ?></td>
                <td><?php echo number_format($item->TOTAL, 2, ',', '.'); ?></td>
                <td><?php echo $item->NOME_UNIDADE; ?></td>
                <td><?php echo $item->NOME_PRODUTO; ?></td>
            </tr>
        <?php } ?>
    </tbody>

</table>
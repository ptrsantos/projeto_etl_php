<div class="container">

    <h4><strong><?= $dados->titulo ?></strong></h4>
    <hr>

    <div class="card">
        <div class="card-body">

            <form name="formulario" id="filtro" method="post" action="paginas/filtro">

                <div class="form-row">
                    <div class="col">
                        <label for="inicial">Posição Inicial</label>
                        <input type="date" class="form-control" name="inicial" placeholder="dd/mm/aaaa">
                    </div>
                    <div class="col">
                        <label for="final">Posição Final</label>
                        <input type="date" class="form-control" placeholder="dd/mm/aaaa" name="final">
                    </div>
                </div>

                <br>

                <div class="form-row">
                    <div class="col">
                        <label for="unidade">Unidade</label>
                        <select id="unidade" class="form-control">
                        <option selected>Selecione...</option>
                            <option value="0">TODAS UNIDADES</option>
                            <?php $cont = 0;
                            foreach ($dados->unidades as $unidade) { ?>
                                <option value="<?php echo ++$cont; ?>"><?php echo $unidade->no_unidade; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="col">
                        <label for="produto">Produto</label>
                        <select id="produto" class="form-control">
                            <option selected>Selecione...</option>
                            <option value="0">TODAS PRODUTOS</option>
                            <?php $cont = 0;
                            foreach ($dados->produtos as $produto) { ?>
                                <option value="<?php echo ++$cont; ?>"><?php echo $produto->no_produto; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                </div>

                <br>
                <input type="submit" class="btn btn-primary" value="Filtrar" id="enviar">
            </form>
        </div>

    </div>

    <!-- <button id="enviar">Teste</button> -->

    <!-- Button trigger modal -->
    <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-keyboard="false" data-backdrop="static">
            Launch demo modal
        </button> -->

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">

                    <div class="modal-body">

                        <div class="row justify-center" style="padding-left: 40%;">

                            <div class="col-3">
                                <div class="spinner-border text-info" role="status" style="width: 3rem; height: 3rem;">
                                    <span class="sr-only">Loading...</span>
                                </div>
                            </div>

                        </div>
                        <h3 style="padding-left: 30%;">Aguarde...</h3>
                    </div>
                </div>

            </div>
        </div>

    <script>
        $(document).ready(function() {
            // $("#enviar").click(function(event){
            //     event.preventDefault();
            //     //$("#exampleModal").modal('show');
            //     // $.ajax({url: "paginas/filtro", success: function(result){
            //     //     alert("ajax retornou")
            //     //     debugger
            //     //     $("#div1").html(result);
            //     // }});
            // });


            $("form[name='formulario']").submit(function(event){
                açert("clicou")
                event.preventDefault();
                $.ajax({
                    url: "paginas/filtro",
                    type: "POST",
                    data: $(this).serialize(),
                    dataType: "json",
                    success: function(result){
                    console.log(result);
                  }
                });
            });

        });
    </script>
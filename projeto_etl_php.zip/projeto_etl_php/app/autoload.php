<?php
echo 'Entrou no autoload';
spl_autoload_register(function($classe){
    echo 'Classe: '.$classe.'<br>';
    $diretorios = [
        'Controllers',
        'Helpers',
        'Libraries',
        'Models'
    ];
    foreach($diretorios as $diretorio):
        echo 'Diretório: '.$diretorio.'<br>';
        echo __DIR__.DIRECTORY_SEPARATOR.$diretorio.DIRECTORY_SEPARATOR.$classe.'.php<br>';
        if(file_exists((__DIR__.DIRECTORY_SEPARATOR.$diretorio.DIRECTORY_SEPARATOR.$classe.'.php'))):
            require_once($diretorio);
        endif;
    endforeach;

});
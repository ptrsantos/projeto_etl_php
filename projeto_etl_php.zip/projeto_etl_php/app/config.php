<?php

// echo dirname(__FILE__);
// echo '<br>';
// echo dirname(dirname(__FILE__));

define('APP', dirname(__FILE__));
define('URL', 'http://localhost/projeto_etl_php/');
define('APP_NOME', 'curso de PHP7 Orientado a Objetos e MVC');
const APP_VERSAO = '1.0.0';
<?php
    // include '.\..\app\autoload.php';
    // include '.\..\app\config.php';

    include './../app/config.php';
    include './../app/Libraries/Rota.php';
    include './../app/Libraries/Controller.php';
    include './../app/Libraries/Database.php';

    $db = new Database;

// session_test.php

session_start();

// if ( ! empty($_SESSION['token']) )
//     echo 'Session: ' . $_SESSION['token'];
// else
//     echo 'Session not set.';

$token = uniqid(mt_rand(), true);
$_SESSION['token'] = $token;

    
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="<?= URL ?>public/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= URL ?>public/css/style.css">
    <link rel="stylesheet" href="<?= URL ?>public/DataTable/datatables.min.css"/>
    <link rel="stylesheet" href="<?= URL ?>public/jquery-ui-1.13.2/jquery-ui.min.csss"/>
    <link rel="stylesheet" href="<?= URL ?>public/jquery-ui-1.13.2/jquery-ui.theme.min.css"/>
    

    <script src="<?= URL ?>public/js/jquery-3.6.0.js"></script>
    <script src="<?= URL ?>public/js/bootstrap.min.js"></script>
    <script src="<?= URL ?>public/DataTable/datatables.min.js"></script>
    <script src="<?= URL ?>public/jquery-ui-1.13.2/jquery-ui.min.js"></script>




    <title><?= APP_NOME ?></title>
</head>
<body>
    <?php include '../app/Views/header.php' ?>; 
    <div class="container-fluid">
        <?php  $rotas = new Rota; ?>;
    </div>
    <?php include '../app/Views/footer.php'?>
</body>
</html>